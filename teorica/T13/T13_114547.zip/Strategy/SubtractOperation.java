public class SubtractOperation implements Operation {
    @Override
    public double performOperation(int a, int b) {
        return a - b;
    }
}