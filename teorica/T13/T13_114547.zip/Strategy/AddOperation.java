public class AddOperation implements Operation {
    @Override
    public double performOperation(int a, int b) {
        return a + b;
    }
}
