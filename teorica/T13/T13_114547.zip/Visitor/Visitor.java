public interface Visitor {
    void visitCircle(Circle circle);
    void visitRetangle(Retangle rectangle);
}
