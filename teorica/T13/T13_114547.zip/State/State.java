public interface State {
    public void pull(CeilingFan fan);
    public String getName();
}
