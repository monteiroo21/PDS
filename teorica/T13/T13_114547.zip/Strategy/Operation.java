public interface Operation {
    public double performOperation(int a, int b);
}
