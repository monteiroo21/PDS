interface Employee {
    void showDetails();
} 