public interface Observer {
    public void setMeasurements(int temperature, int humidity);    
}
