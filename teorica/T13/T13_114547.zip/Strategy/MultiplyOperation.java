public class MultiplyOperation implements Operation {
    @Override
    public double performOperation(int a, int b) {
        return a * b;
    }
}
