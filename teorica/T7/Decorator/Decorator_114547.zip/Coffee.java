package Decorator;

interface Coffee {
    Double getCost();
    String getDescription();
}
